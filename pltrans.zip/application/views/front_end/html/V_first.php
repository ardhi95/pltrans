<!DOCTYPE html>
<html>
<head>
<title>PL Trans</title>
<link href="<?= base_url(); ?>assets/front_end/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!--theme-style-->
<link href="<?= base_url(); ?>assets/front_end/css/style.css" rel="stylesheet" type="text/css" media="all" />	
<link href="<?= base_url(); ?>assets/front_end/css/font-awesome.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/front_end/css/calendar.css" rel="stylesheet">
<link href="<?= base_url(); ?>assets/front_end/css/scroll.css" rel="stylesheet">

<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta property="og:title" content="Vide" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!---->
<script src="<?= base_url(); ?>assets/front_end/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/front_end/js/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>assets/front_end/js/calendar.js"></script>
<script src="<?= base_url(); ?>assets/front_end/js/scroll.js"></script>

	<!-- <script src="<?php base_url() ?>assets/front_end/js/jquery.js"></script>
    <script src="<?php base_url() ?>assets/front_end/js/jquery.easing.min.js"></script>
    <script src="<?php base_url() ?>assets/front_end/js/scrolling-nav.js"></script> -->
<!---->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/front_end/css/flexslider.css" type="text/css" media="screen" />
<link href='//fonts.googleapis.com/css?family=Nunito:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>

<!-- requried-jsfiles-for owl -->
<!-- 							<link href="<?= base_url(); ?>assets/front_end/css/owl.carousel.css" rel="stylesheet">
							    <script src="js/owl.carousel.js"></script>
							        <script>
							    $(document).ready(function() {
							      $("#owl-demo").owlCarousel({
							        items : 1,
							        lazyLoad : true,
							        autoPlay : true,
							        navigation : false,
							        navigationText :  false,
							        pagination : true,
							      });
							    });
							    </script> -->
							 <!-- //requried-jsfiles-for owl -->

</head>
<body>