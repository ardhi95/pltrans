<?php $this->load->view('front_end/html/V_first'); ?>
	<div class="banner"></div>
	<?php $this->load->view('front_end/html/V_menu'); ?>
	<div class="content">
		<div class="container">
			<div class="row">
				<h2 class="text-center">Minimal Preview Thumbnails </h2>
	        	<hr/>
			</div>
	    <div class="row">
	    	<!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                <img src="<?= base_url(); ?>assets/front_end/images/car/1.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div><!-- 
	                	<div class="col-lg-6" align="right">
	                		<span class="glyphicon glyphicon-road" > IDR 300</span>
	                	</div> -->
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>

	        <!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                
	                <img src="<?= base_url(); ?>assets/front_end/images/car/2.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div><!-- 
	                	<div class="col-lg-6" align="right">
	                		<i class="fa fa-money" aria-hidden="true"> $ 300</i>
	                	</div> -->
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>
	        <!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                
	                <img src="<?= base_url(); ?>assets/front_end/images/car/3.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div><!-- 
	                	<div class="col-lg-6" align="right">
	                		<i class="fa fa-money" aria-hidden="true"> $ 300</i>
	                	</div> -->
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>
	        <!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                
	                <img src="<?= base_url(); ?>assets/front_end/images/car/4.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div>
	                	<div class="col-lg-6" align="right">
	                		<i class="fa fa-money" aria-hidden="true"> $ 300</i>
	                	</div>
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>
	        <!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                
	                <img src="<?= base_url(); ?>assets/front_end/images/car/5.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div>
	                	<div class="col-lg-6" align="right">
	                		<i class="fa fa-money" aria-hidden="true"> $ 300</i>
	                	</div>
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>
	        <!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                
	                <img src="<?= base_url(); ?>assets/front_end/images/car/6.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div>
	                	<div class="col-lg-6" align="right">
	                		<i class="fa fa-money" aria-hidden="true"> $ 300</i>
	                	</div>
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>Tanpa Sopir</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>
	        <!-- Armada -->
	        <div class="col-sm-6 col-md-4">
	                
	                <img src="<?= base_url(); ?>assets/front_end/images/car/7.png" alt="..." class="img-thumbnail">
	                <h2>
	                    Murah Meriah
	                </h2>
	                <div class="col-xs-12">
	                	<div class="col-lg-6">
	                		<span class="glyphicon glyphicon-user"> 2 Orang</span>
	                	</div>
	                	<div class="col-lg-6" align="right">
	                		<i class="fa fa-money" aria-hidden="true"> $ 300</i>
	                	</div>
	                </div>
	                <div class="col-md-12">
	                	<table class="table table-striped">
	                		<tr>
	                			<td>12 Jam</td>
	                			<td>IDR 200.000</td>
	                		</tr>
	                	</table>
	                </div>
	                <div class="clearfix"></div>
	        </div>
    	</div>
    	<!-- End Row -->
	</div>
</div>
<div class="jarak">
	
</div>

<?php $this->load->view('front_end/html/V_footer'); ?>