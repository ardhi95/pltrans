<?php $this->load->view('front_end/html/V_first'); ?>
<body>
	<?php $this->load->view('front_end/html/V_menu'); ?>
	<?php $this->load->view('front_end/html/V_homeslide'); ?>
    
			
		<div class="content">
			<!-- Info Wisata -->
			<div class="welcome">
				<div class="container">
					<h2 class="tittle">Info Wisata</h2>
					<div class="wel-grids">
						<div class="col-md-3 wel-grid">
							<img src="<?= base_url(); ?>assets/front_end/images/w1.jpg" class="img-responsive gray" alt=""/>
							<h4>Premier Suite</h4>
							<p>Lorem ipsum dolor sit amet, consect adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed.</p>
						</div>
						<div class="col-md-3 wel-grid">
							<img src="<?= base_url(); ?>assets/front_end/images/w2.jpg" class="img-responsive gray" alt=""/>
							<h4>Deluxe Suite</h4>
							<p>Lorem ipsum dolor sit amet, consect adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed.</p>
						</div>
						<div class="col-md-3 wel-grid">
							<img src="<?= base_url(); ?>assets/front_end/images/w3.jpg" class="img-responsive gray" alt=""/>
							<h4>Luxury Suite</h4>
							<p>Lorem ipsum dolor sit amet, consect adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed.</p>
						</div><div class="col-md-3 wel-grid">
							<img src="<?= base_url(); ?>assets/front_end/images/w3.jpg" class="img-responsive gray" alt=""/>
							<h4>Luxury Suite</h4>
							<p>Lorem ipsum dolor sit amet, consect adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed.</p>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
			<!-- about --> 
			<div class="about-section">
				<div class="container">
					<h2 class="tittle">About PL Trans</h2>
					<div class="about-grids">
						<div class="col-md-6"></div>
						<div class="col-md-6 wel-grid" align="justify">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</div>
					</div>
				</div>
			</div>
			
			
		</div>
<?php $this->load->view('front_end/html/V_footer'); ?>
