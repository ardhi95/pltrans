<?php $this->load->view('front_end/html/V_first'); ?>
	<div class="banner"></div>
	<?php $this->load->view('front_end/html/V_menu'); ?>
	
	<div class="content">
			<div class="restaurant">
				<div class="container">
					<h2 class="tittle">Info Wisata</h2>
					<div class="rest-grids">
						<div class="col-md-8 rest-grid">
							<div class="rest-top">
								<h3>Royal Hyanni Dining</h3>
								<img src="<?= base_url() ?>assets/front_end/images/r1.jpg" class="img-responsive gray" alt=""/>
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled printer took a galley of type and scrambled since it to make a type specimen book.</p>
								<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
							</div>
							<div class="rest-bottom">
								<div class="col-md-6 rest-left">
									<a href="#"><img src="<?= base_url() ?>assets/front_end/images/r2.jpg" class="img-responsive gray" alt=""/></a>
									<h4>Family Dining</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="col-md-6 rest-right">
								<img src="<?= base_url() ?>assets/front_end/images/r3.jpg" class="img-responsive gray" alt=""/>
									<h4>Casual Dining</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="rest-bottom">
								<div class="col-md-6 rest-left">
									<img src="<?= base_url() ?>assets/front_end/images/r4.jpg" class="img-responsive gray" alt=""/>
									<h4>Buffet Dining</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="col-md-6 rest-right">
								<img src="<?= base_url() ?>assets/front_end/images/r5.jpg" class="img-responsive gray" alt=""/>
									<h4>Wedding Dining</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="rest-bottom">
								<div class="col-md-6 rest-left">
									<img src="<?= base_url() ?>assets/front_end/images/r6.jpg" class="img-responsive gray" alt=""/>
									<h4>Bars and Lounges </h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="col-md-6 rest-right">
								<img src="<?= base_url() ?>assets/front_end/images/r8.jpg" class="img-responsive gray" alt=""/>
									<h4>Outdoor Dining </h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="clearfix"></div>
							</div>
						</div>
						<div class="col-md-4 rest-grid1">
							<h3>Calendar</h3>
							<div class="reser-grid1">
								<div id="my-calendar"></div>
							</div>
							<div class="lastest">
								<div class="lastest-top">
								<img src="<?= base_url() ?>assets/front_end/images/w5.jpg" class="img-responsive gray" alt=""/>
									<h4>Luxury Resort</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
								<div class="lastest-top">
								<img src="<?= base_url() ?>assets/front_end/images/ga7.jpg" class="img-responsive gray" alt=""/>
									<h4>Swinging Pool</h4>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown .</p>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
</body>
<?php $this->load->view('front_end/html/V_footer'); ?>