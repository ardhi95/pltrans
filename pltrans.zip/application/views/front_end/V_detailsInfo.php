<?php $this->load->view('front_end/html/V_first'); ?>
<div class="banner"></div>


	<div class="content">
		<div class="restaurant">
			<div class="container">
	
			</div>
		</div>
	</div>

<?php $this->load->view('front_end/html/V_footer'); ?>