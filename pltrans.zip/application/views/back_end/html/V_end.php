<div class="copy_layout">
         <p>Copyright © 2016 PL Trans | Design by <a href="http://thppl.net/" target="_blank">Thppl</a> </p>
        </div>  
        </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="<?= base_url() ?>assets/back_end/css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="<?= base_url() ?>assets/back_end/js/metisMenu.min.js"></script>
<script src="<?= base_url() ?>assets/back_end/js/custom.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url() ?>assets/back_end/js/bootstrap.min.js"></script>
</body>
</html>
