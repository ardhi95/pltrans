<!DOCTYPE HTML>
<html>
<head>
<title>PL Trans</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="<?= base_url() ?>assets/back_end/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="<?= base_url() ?>assets/back_end/css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="<?= base_url() ?>assets/back_end/css/lines.css" rel='stylesheet' type='text/css' />
<link href="<?= base_url() ?>assets/back_end/css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="<?= base_url() ?>assets/back_end/js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Nav CSS -->
<link href="<?= base_url() ?>assets/back_end/css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="<?= base_url() ?>assets/back_end/js/metisMenu.min.js"></script>
<script src="<?= base_url() ?>assets/back_end/js/custom.js"></script>
<!-- Graph JavaScript -->
<script src="https://use.fontawesome.com/9208207aa1.js"></script>
<!-- CK Editor -->
<script type="text/javascript" src="<?php echo base_url().'assets/ckeditor/ckeditor.js';?>"></script>
<script type="text/javascript">var base_url = '<?php echo base_url();?>';</script>
<!--
<script src="<?= base_url() ?>assets/back_end/js/d3.v3.js"></script>
<script src="<?= base_url() ?>assets/back_end/js/rickshaw.js"></script>
-->
<!-- datatables -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<script type="text/javascript">
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>

<script type="text/javascript">
function confirm_delete() {
  return confirm('Are You Sure ?');
}
</script>
</head>
<body>