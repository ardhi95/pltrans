<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_info extends CI_Controller {

	public function index()
	{
		$this->load->view('front_end/V_info');		
	}

}

/* End of file C_info.php */
/* Location: ./application/controllers/C_info.php */