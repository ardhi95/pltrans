<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_paket extends CI_Controller {

	public function index()
	{
		$this->load->view('front_end/V_paket');		
	}

}

/* End of file C_paket.php */
/* Location: ./application/controllers/C_paket.php */