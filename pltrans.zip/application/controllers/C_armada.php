<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_armada extends CI_Controller {

	public function index()
	{
		$this->load->view('front_end/V_armada');		
	}

}

/* End of file C_armada.php */
/* Location: ./application/controllers/C_armada.php */